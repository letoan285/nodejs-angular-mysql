import { Title } from '@angular/platform-browser';

export interface Order {
    id?: number;
    customer_id?: number;
    user_id?: number;
    deliver_id?: number;
    payment_id?: number;
    status_id?: number;
    coupon_id?: number;
    transaction_date?: Date;
}
