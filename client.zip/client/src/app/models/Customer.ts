import { Title } from '@angular/platform-browser';

export interface Customer {
    id?: number;
    role_id?: number;
    customer_name?: string;
    sex?: string;
    dob?: Date;
    phone?: string;
    email?: string;
    username?: string;
    password?: string;
    code?: string;
    active?: 1;
    city?: string;
    district?: string;
    commune?: string;
    village?: string;
    lat?: number;
    lng?: number;
    remember_token?: string;
    deleted_at?: Date;
    created_at?: Date;
    updated_at?: Date;
}
