import { Title } from '@angular/platform-browser';

export interface Category {
    id?: number;
    name?: string;
    slug?: string;
    description?: string;
    parent_id?: number;
    image?: string;
    created_at?: Date;
    updated_at?: Date;
}
