import { Title } from '@angular/platform-browser';

export interface Product {
    id?: number;
    name?: string;
    slug?: string;
    description?: string;
    category_id?: number;
    price?: number;
    image?: string;
    created_at?: Date;
    updated_at?: Date;
}
