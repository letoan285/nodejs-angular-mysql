import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Product } from '../../models/Product';
import { ProductsService } from '../../services/products.service';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.scss']
})
export class ProductFormComponent implements OnInit {

  product: Product = {
    id: 0,
    name: '',
    slug: '',
    description: '',
    image: '',
    price: 0,
    category_id: 0,
    created_at: new Date(),
    updated_at: new Date()
  };
  edit: boolean;
  constructor(private productService: ProductsService, private router: Router, private activedRoute: ActivatedRoute) { }

  ngOnInit() {
    const params = this.activedRoute.snapshot.params;
    if (params.id) {
      this.productService.getProduct(params.id)
        .subscribe(
          res => {
            console.log(res);
            this.product = res;
            this.edit = true;
          },
          err => console.log(err)
        );
    }
  }

  saveNewProduct() {
    delete this.product.created_at;
    delete this.product.updated_at;
    delete this.product.id;
    this.productService.saveProduct(this.product)
      .subscribe(
        res => {
          console.log(res);
          this.router.navigate(['/products']);
        },
        err => console.log(err)
      );
  }
  updateProduct() {
    delete this.product.created_at;
    delete this.product.updated_at;
    this.productService.updateProduct(this.product.id, this.product)
      .subscribe(
        res => {
          console.log(res);
          this.router.navigate(['/products']);
        },
        err => console.log(err)
      );
  }

}
