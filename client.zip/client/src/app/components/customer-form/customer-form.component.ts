import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Customer } from '../../models/Customer';
import { CustomersService } from '../../services/customers.service';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.scss']
})
export class CustomerFormComponent implements OnInit {

  customer: Customer = {
    id: 0,
    role_id: 0,
    customer_name: '',
    sex: '',
    dob: new Date(),
    phone: '',
    email: '',
    username: '',
    password: '',
    code: '',
    active: 1,
    city: '',
    district: '',
    commune: '',
    village: '',
    lat: 0,
    lng: 0,
    remember_token: 'string',
    deleted_at: new Date(),
    created_at: new Date(),
    updated_at: new Date()
  };

  edit: boolean;
  constructor(private customersService: CustomersService, private router: Router, private activedRoute: ActivatedRoute) { }

  ngOnInit() {
    const params = this.activedRoute.snapshot.params;
    if (params.id) {
      this.customersService.getCustomer(params.id)
        .subscribe(
          res => {
            console.log(res);
            this.customer = res;
            this.edit = true;
          },
          err => console.log(err)
        );
    }
  }
  updateCustomer() {

  }
  saveNewCustomer() {

  }

}
