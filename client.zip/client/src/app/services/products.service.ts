import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Product } from '../models/Product';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  API_URL = 'http://localhost:3000/api';
  constructor(private http: HttpClient) { }
  getProducts() {
    return this.http.get(`${this.API_URL}/products`);
  }

  getProduct(id: string) {
    return this.http.get(`${this.API_URL}/products/${id}`);
  }

  deleteProduct(id: string) {
    return this.http.delete(`${this.API_URL}/products/${id}`);
  }

  saveProduct(product: Product) {
    return this.http.post(`${this.API_URL}/products`, product);
  }

  updateProduct(id: string|number, updatedProduct: Product): Observable<Product> {
    return this.http.put(`${this.API_URL}/products/${id}`, updatedProduct);
  }
}
